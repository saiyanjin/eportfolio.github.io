package go;

public enum ContenuCase{
	BLACK,WHITE,EMPTY;
}
