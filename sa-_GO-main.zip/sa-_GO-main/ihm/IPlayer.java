package ihm;

import go.Go;

public interface IPlayer {
	public String getMove(Go g, PlayerTurn pt);
	
}
